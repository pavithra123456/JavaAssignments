package AssignmentSort;

import java.util.PriorityQueue;


public class PriorityQueueEx {
	public static void main(String[] args) {
		 PriorityQueue<Car> deviceList = new PriorityQueue<>(10, new ComparatorEx.sortByDecPrice());
		 deviceList.add(new Car("Indica",100000));
		 deviceList.add(new Car("BMW", 3500000));
		 deviceList.add(new Car("Audi", 200000));
		 deviceList.add(new Car("Maruti", 40000));
		 System.out.println("Car list in decreasing order with price is  : \n");

		 for (Car device : deviceList) {
			System.out.println(device.getName() + "\t"+device.getPrice());
		}	
	
}

}