package exilant.mailValidation;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
/**
 * Servlet implementation class MailServlet
 */
@WebServlet("/MailServlet")
public class MailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String uName = request.getParameter("uname");
		String pass = request.getParameter("pwd");
		
		response.setContentType("text.html");
		PrintWriter out = response.getWriter();
		
		
		if (uName.equals("Test") && pass.equals("Test"))
		{
			//success
			out.println("<html><body><h1>Welcome  " + uName + " to Gmail"+ "</h1></body></html>");
			
			out.println("<A HREF=\"http://www.google.com\">Google</A>");
			out.println("<A HREF=\"Dataone\">Country List</A><br/>");
			out.println("<A HREF=\"satya.sent.jsp\">Sent Mail</A>");
		}
		else
		{
			//error
			
			out.println("<html><body><h2 style = 'color:red'>sorry invalid Details</h2>|</body></html>");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
