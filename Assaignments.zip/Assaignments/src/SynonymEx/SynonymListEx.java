package SynonymEx;

import java.util.HashMap;
import java.util.Scanner;

public class SynonymListEx {

	public static void main(String[] args) {
		HashMap<String, String[]> list = new HashMap<String,String[]>();
		list.put("Angry", new String[]{"mad","furious"});
		list.put("Beautiful",new String[]{"pretty","lovely"} );
		list.put("Cool", new String[]{"chilly","cold","frosty"});
		list.put("Dangerous", new String[]{"hazardous","perilous"});
		list.put("Honest", new String[]{"Honorable","Fair"});
		System.out.println("Enter the word for which you want synonym : ");
		Scanner sc = new Scanner(System.in);
		String key = sc.next();
		if (list.containsKey(key)) {
			String[] array = list.get(key);
			System.out.println("Synonym are : ");
			for (String string : array) {
				System.out.println(string);
			}
		} else {
			System.out.println("key not found");
		}
		
		
		
		
	}
	
}
