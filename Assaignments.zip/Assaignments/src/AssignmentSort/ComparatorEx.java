package AssignmentSort;

import java.util.Comparator;



public class ComparatorEx {

	public static class sortByDecPrice implements Comparator<Car> {

		@Override
		public int compare(Car o1, Car o2) {
			// TODO Auto-generated method stub
			return o2.getPrice() - o1.getPrice();		}

		}
	
	public  class sortByIncPrice implements Comparator<Car> {

		@Override
		public int compare(Car o1, Car o2) {
			// TODO Auto-generated method stub
			return o1.getPrice() - o2.getPrice();		}

			 

    }
		public  class sortByIncName implements Comparator<Car> {

			@Override
			public int compare(Car o1, Car o2) {
				// TODO Auto-generated method stub
				return o1.getName().compareTo(o2.getName());
			}

			

     }
		public  class sortByDecName implements Comparator<Car> {

			@Override
			public int compare(Car o1, Car o2) {
				// TODO Auto-generated method stub
				return o2.getName().compareTo(o1.getName());
			}

			

}
}
